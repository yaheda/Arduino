                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2163939
Electronics Project Box 100x60x27mm by rich1051414 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

A project enclosure box for electronics. I needed this for a voltage and amperage display monitoring the load on a power supply as well as serving as a junction box. I have included both boxes as someone may find the junction box with the holes precut useful for their own purpose.

Both snap fit and screw fit, so you can have easy access while diagnosing, and then you can secure it when good to go. I was unable to find a project box around this size that was both snap fit and also could be screwed shut, so 3d print it, I did. 

You should know that the lid is reduced in size by 1% (Effectively 1mm), to compensate for inaccuracies in my printer. If you have a very precisely calibrated printer so you would rather have the lid perfectly sized, just scale the lid up to 101.1%. I assume this would cause a lid too large for the box for most people, so the 1mm extra tolerance is default.